<nav>
	<a href="index.php" style="text-decoration:none; color:black;">KAY'S SHOES</a>
	<ul style="list-style-type: none;">
		<li style="float:right";><a href="cart.php" style="padding: 16px; text-decoration: none;">Cart</a></li>
		<li style="float:right";><a href="logout.php" style="padding: 16px; text-decoration: none;">Logout</a></li>
	</ul>
</nav>